# Bloguito

Personal blog about technology. You can find some of my work and compiled posts.

Based on the [Minima template](https://github.com/jekyll/minima)

## Executing

```shell
bundle exec jekyll serve
```